///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package projetopoo.acesso;
//
//import java.util.ArrayList;
//import projetopoo.erro.ConexaoException;
//import projetopoo.erro.RepositorioException;
//import projetopoo.negocio.basica.Fornecedor;
//
///**
// *
// * @author victor
// */
//public class DAOFornecedor implements IDAOFornecedor {
//    @Override
//    public void alterar(Fornecedor fornecedor) throws ConexaoException, RepositorioException {
//       
//    }
//
//    @Override
//    public void inserir(Fornecedor fornecedor) throws ConexaoException, RepositorioException {
//    }
//
//    @Override
//    public void excluir(Integer id) throws ConexaoException, RepositorioException {
//    }
//
//    @Override
//    public void excluir(Fornecedor fornecedor) throws ConexaoException, RepositorioException {
//    }
//
//    @Override
//    public ArrayList<Fornecedor> listar() throws ConexaoException, RepositorioException {
//    }
//
//    @Override
//    public Fornecedor pesquisar(Integer id) throws ConexaoException, RepositorioException {
//    }
//}
